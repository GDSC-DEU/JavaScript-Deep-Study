function JavaScriptDeepStudy(name, book, process){
    let name = new Array("최정혜", "김영주", "김현지", "손진영", "조진혁", "윤한영");
    let book = new Array("자바스크립트완벽가이드7판", "자바스크립트완벽가이드7판", "자바스크립트완벽가이드7판", "자바스크립트완벽가이드7판", "자바스크립트완벽가이드7판", "자바스크립트완벽가이드7판");
    let process = new Array("진행중", "진행중", "진행중", "진행중", "진행중", "잠시중단");    

    function Person(gender, age, language, fruit){
        let gender = ("여", "여", "여", "남", "남", "남");
        let language = ("JavaScript", "JavaScript", "JavaScript", "JavaScript", "TypeScript", "JavaScript");
        let age = ("26", "24", "23", "25", "22", "25");
        let fruit = ("StrawBerry", "StrawBerry", "StrawBerry", "Apple", "Grape", "Orange");
    }
}


class YoungJoo {
    if(name[0] )
}